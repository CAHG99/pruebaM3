# SPA event management
```
Nombre:Cesar Hernandez
Clan:Manglar
Correo:cehergra1999@gmail.com
CC:1234096453
```
## 👀 Description

A single page Application (SPA) for an organizer to manage events and assistants.
Main functionalities:

*Registration / login with roles ** admin ** and ** visitor **.
*Protected Routes (`Router.js`) and session persistence in ** LocalStorage **.
*Complete event of events in a ** Json -Server **.
* Visitors can register if there is quota.
* Responsible interface (HTML5 + CSS3) and JavaScript is Modules.

---

## 🚀 Quick Start

1. ** Install node.js ** (> = 18) and global units: 
`` Bash 
NPM Install -G JSON-SERVER Live-Server 
``

2. ** Download ** This project and enters the folder 

3. ** Lanhes the Backend ** (Json -Server): 
`` Bash 
NPM Run Server 
# Lift at http: // localhost: 3000 
``

4. ** Spears the border ** (Live-Server): 
`` Bash 
NPM RUN START 
# Automatically open http://127.0.0.1:8080/#/login 

---

## 🗂️ Structure

```
CESAR-Hdez/
├── public/                    
│   ├── index.html              
│   └── styles.css         
├── src/                       
│   ├── router/
│   │   └── Router.js         
│   ├── services/
│   │   └── api.js           
│   ├── utils/
│   │   └── auth.js            
│   ├── views/            
│   │   ├── CreateEvent.js
│   │   ├── Dashboard.js
│   │   ├── EditEvent.js
│   │   ├── Login.js
│   │   ├── NotFound.js
│   │   └── Register.js
│   └── main.js                 
├── db.json                    
├── package.json             
├── postman_collection.json     
└── README.md  
```

---

## 🧪 Postman tests

Import `postman_collection.json` and proof:
*** auth **: `post /users` (registration),` get /users? Email = ... & password = ... `(login)
*** Events **: `Get /Events`,` Post /Events`, `Put /Events /: ID`,` Delete /Events /: ID`

---

## 🔑 Admin user

| Role | Email | Password |
| ---- | ------ | ---------- |
| admin | admin123@gmail.com | admin123 |

> ** Tip: ** Change the password in `db.json` if you wish.
---
## 📃 Notes

*All private routes redirect to ** login ** if the session does not exist.
*If the authenticated user opens `/login` or`/register` is redirect to ** dashboard **.
* If the route does not exist, `notfound` is shown.