import { register } from '../utils/auth.js';

export default function Register () {
  const div = document.createElement('div');
  div.innerHTML = `
    <h2>Registro</h2>
    <form id="regForm">
      <label>Nombre</label>
      <input id="name" required/>
      <label>Email</label>
      <input type="email" id="email" required/>
      <label>Contraseña</label>
      <input type="password" id="password" required/>
      <button type="submit">Crear cuenta</button>
      <p>¿Ya tienes cuenta? <a href="#/login">Inicia Sesión</a></p>
    </form>
    <style>
      #eventos {
        background: #f9f9f9;
      }
        h2{
        color: #333;
        background: #e0e0e0;
        padding: 10px;
        border-radius: 5px;}
      form {
        display: flex;
        flex-direction: column;
      }
      label {
        margin-top: 10px;
      }
      input, button {
        margin-top: 5px;
      }

  `;

  div.querySelector('#regForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const user = {
      name: div.querySelector('#name').value,
      email: div.querySelector('#email').value,
      password: div.querySelector('#password').value,
      role: 'visitante'
    };
    try {
      await register(user);
      alert('Registrado, ahora inicia sesión');
      location.hash = '/login';
    } catch (err) {
      alert(err.message);
    }
  });

  return div;
}