import API from '../services/api.js';
import { logout } from '../utils/auth.js';

export default function Dashboard () {
  const user = JSON.parse(localStorage.getItem('session'));
  const div = document.createElement('div');

  div.innerHTML = `
    <h2>Bienvenido al panel de control, ${user.name}</h2>
    <button id="logout">Cerrar sesión</button>
    ${user.role === 'admin' ? '<button id="crear">Crear Evento</button>' : ''}
    <section id="eventos"><h3>Eventos</h3></section>
    <style>
      #eventos {
        background: #f9f9f9;
      }
        h2{
        color: #333;
        background: #e0e0e0;
        padding: 10px;
        border-radius: 5px;}
      .card {
        border: 1px solid #ccc;
        padding: 10px;
        margin: 10px;
      }
      .card h4 {
        margin: 0 0 10px;
      }
      .card button {
        margin-right: 5px;
      }
    div{
      display: flex;
      justify-content: center;
      flex-direction: column;
    }  
    </style>
    `;

  div.querySelector('#logout').addEventListener('click', () => {
    logout();
    location.hash = '/login';
  });

  if (user.role === 'admin') {
    div.querySelector('#crear').addEventListener('click', () => {
      location.hash = '/dashboard/events/create';
    });
  }

  const eventosSec = div.querySelector('#eventos');

  API.get('/events').then(events => {
    if (!events.length) eventosSec.innerHTML += '<p>Sin eventos.</p>';
    events.forEach(ev => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <h4>${ev.title}</h4>
        <p>${ev.date}</p>
        <p>Cupo: ${ev.capacity} — Registrados: ${ev.registered?.length || 0}</p>
      `;
      if (user.role === 'admin') {
        card.innerHTML += `
          <button data-id="${ev.id}" class="edit">Editar</button>
          <button data-id="${ev.id}" class="del">Eliminar</button>
        `;
      } else {
        card.innerHTML += `<button data-id="${ev.id}" class="ins">Inscribirme</button>`;
      }
      eventosSec.appendChild(card);
    });

    eventosSec.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (!id) return;
      if (e.target.classList.contains('del')) {
        await API.delete('/events/' + id);
        location.reload();
      }
      if (e.target.classList.contains('edit')) {
        location.hash = '/dashboard/events/edit?id=' + id;
      }
      if (e.target.classList.contains('ins')) {
        const event = await API.get('/events/' + id);
        if (!event.registered) event.registered = [];
        if (event.registered.includes(user.id)) return alert('Ya estás inscrito');
        if (event.registered.length >= event.capacity) return alert('Cupo lleno');
        event.registered.push(user.id);
        await API.put('/events/' + id, event);
        alert('Inscrito ✔');
        location.reload();
      }
    });
  });

  return div;
}