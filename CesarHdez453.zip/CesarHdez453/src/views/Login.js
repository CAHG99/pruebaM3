import { login } from '../utils/auth.js';

export default function Login () {
  const div = document.createElement('div');
  div.innerHTML = `
    <h2>Iniciar Sesión</h2>
    <form id="loginForm">
      <label>Email</label>
      <input type="email" id="email" required/>
      <label>Contraseña</label>
      <input type="password" id="password" required/>
      <button type="submit">Entrar</button>
      <p>¿No tienes cuenta? <a href="#/register">Regístrate</a></p>
    </form>
    <style>
      #eventos {
        background: #f9f9f9;
      }
        h2{
        color: #333;
        background: #e0e0e0;
        padding: 10px;
        border-radius: 5px;}
      form {
        display: flex;
        flex-direction: column;     
    </style>
  `;

  div.querySelector('#loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = div.querySelector('#email').value;
    const pass = div.querySelector('#password').value;
    try {
      await login(email, pass);
      location.hash = '/dashboard';
    } catch (err) {
      alert(err.message);
    }
  });

  return div;
}