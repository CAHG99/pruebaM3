import API from '../services/api.js';

export default function EditEvent (params) {
  const div = document.createElement('div');
  const id = params.id;

  div.innerHTML = '<h2>Editar Evento</h2><p>Cargando...</p>';

  API.get('/events/' + id).then(ev => {
    div.innerHTML = `
      <h2>Editar Evento</h2>
      <form id="editForm">
        <label>Título</label>
        <input id="title" value="${ev.title}" required/>
        <label>Fecha</label>
        <input type="date" id="date" value="${ev.date}" required/>
        <label>Cupo</label>
        <input type="number" id="cap" value="${ev.capacity}" required/>
        <button type="submit">Actualizar</button>
      </form>
      <style>
        #eventos {
          background: #f9f9f9;
        }
          h2{
          color: #333;
          background: #e0e0e0;
          padding: 10px;
          border-radius: 5px;}
        form {
          display: flex;
          flex-direction: column;
        }
        label {
          margin-top: 10px;
        }
        input, button {
          margin-top: 5px;
        }
      </style>
    `;

    div.querySelector('#editForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      ev.title = div.querySelector('#title').value;
      ev.date = div.querySelector('#date').value;
      ev.capacity = parseInt(div.querySelector('#cap').value);
      await API.put('/events/' + id, ev);
      location.hash = '/dashboard';
    });
  });

  return div;
}