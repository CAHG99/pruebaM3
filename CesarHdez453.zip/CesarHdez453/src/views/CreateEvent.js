import API from '../services/api.js';

export default function CreateEvent () {
  const div = document.createElement('div');
  div.innerHTML = `
    <h2>Crear Evento</h2>
    <form id="createForm">
      <label>Título</label>
      <input id="title" required/>
      <label>Fecha</label>
      <input type="date" id="date" required/>
      <label>Cupo</label>
      <input type="number" id="cap" required/>
      <button type="submit">Guardar</button>
    </form>
    <style>
      #eventos {
        background: #f9f9f9;
      }
        h2{
        color: #333;
        background: #e0e0e0;
        padding: 10px;
        border-radius: 5px;}
      form {
        display: flex;
        flex-direction: column;
      }
      label {
        margin-top: 10px;
      }
      input, button {
        margin-top: 5px;
      }
  `;

  div.querySelector('#createForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      title: div.querySelector('#title').value,
      date: div.querySelector('#date').value,
      capacity: parseInt(div.querySelector('#cap').value),
      registered: []
    };
    await API.post('/events', data);
    location.hash = '/dashboard';
  });

  return div;
}