export default function NotFound () {
  const div = document.createElement('div');
  div.innerHTML = '<h2>404 – Page not Found</h2><a href="#/dashboard">Volver al inicio</a>';
  return div;
}