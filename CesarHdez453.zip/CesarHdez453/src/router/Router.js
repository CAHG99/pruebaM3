import Login from '../views/Login.js';
import Register from '../views/Register.js';
import Dashboard from '../views/Dashboard.js';
import CreateEvent from '../views/CreateEvent.js';
import EditEvent from '../views/EditEvent.js';
import NotFound from '../views/NotFound.js';
import { isAuthenticated } from '../utils/auth.js';

const app = document.getElementById('app');

// Rutas declarativas
const routes = {
  '/login': { component: Login, public: true },
  '/register': { component: Register, public: true },
  '/dashboard': { component: Dashboard, private: true },
  '/dashboard/events/create': { component: CreateEvent, private: true, role: 'admin' },
  '/dashboard/events/edit': { component: EditEvent, private: true, role: 'admin' }
};

export default function Router () {
  const [rawPath, queryString] = (location.hash.slice(1) || '/login').split('?');
  const route = routes[rawPath];

  // Ruta inexistente
  if (!route) {
    render(NotFound());
    return;
  }

  // Redirecciones
  if (route.public && isAuthenticated()) {
    location.hash = '/dashboard';
    return;
  }

  if (route.private && !isAuthenticated()) {
    location.hash = '/login';
    return;
  }

  if (route.role) {
    const user = JSON.parse(localStorage.getItem('session'));
    if (!user || user.role !== route.role) {
      render(NotFound());
      return;
    }
  }

  // Render
  const params = Object.fromEntries(new URLSearchParams(queryString || ''));
  render(route.component(params));
}

// Helper render
function render (node) {
  app.innerHTML = '';
  app.appendChild(node);
}