// Importa el módulo API que contiene los métodos para hacer peticiones HTTP
import API from '../services/api.js';

// Consulta a la API por un usuario que coincida con el email y password
export const login = async (email, password) => {
  const users = await API.get(`/users?email=${email}&password=${password}`);
  if (users.length) {
    localStorage.setItem('session', JSON.stringify(users[0]));
    return users[0];
  }
  throw new Error('Credenciales incorrectas');
};

//Registra un nuevo usuario en la base de datos
export const register = (user) => API.post('/users', user);
//Cierra sesión eliminando la información del usuario del localStorage
export const logout = () => localStorage.removeItem('session');
//Verifica si hay una sesión activa
export const isAuthenticated = () => !!localStorage.getItem('session');
