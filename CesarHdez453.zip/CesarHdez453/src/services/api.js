// URL base del servidor json-server
const BASE_URL = 'http://localhost:3000';

// Función genérica para realizar solicitudes HTTP
// configuración para fetch (método, headers, body, etc.)
function request (url, options = {}) {
  return fetch(BASE_URL + url, options)
    .then(res => {
      if (!res.ok) throw new Error('Error HTTP');
      return res.json();
    });
}

// Métodos para obtener datos
export default {
  get: (url) => request(url, { method: 'GET' }),
  post: (url, data) => request(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }),
  put: (url, data) => request(url, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }),
  delete: (url) => request(url, { method: 'DELETE' })
};

