import Router from './router/Router.js';

window.addEventListener('hashchange', Router);
window.addEventListener('DOMContentLoaded', Router);